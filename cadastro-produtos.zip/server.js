const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

let produtos = [];

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
    secret: 'segredo',
    resave: false,
    saveUninitialized: true
}));

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.post('/login', (req, res) => {
    const usuario = req.body.usuario;
    req.session.usuario = usuario;

    const agora = new Date().toLocaleString();
    res.cookie('ultimoAcesso', agora, { maxAge: 24 * 60 * 60 * 1000 });
    res.redirect('/cadastro');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/login.html');
});

app.get('/cadastro', (req, res) => {
    if (!req.session.usuario) {
        return res.redirect('/');
    }
    res.sendFile(__dirname + '/public/cadastro.html');
});

app.post('/cadastro', (req, res) => {
    if (!req.session.usuario) {
        return res.redirect('/');
    }

    produtos.push(req.body);
    res.redirect('/produtos');
});

app.get('/produtos', (req, res) => {
    if (!req.session.usuario) {
        return res.redirect('/');
    }

    const ultimoAcesso = req.cookies.ultimoAcesso || "Não identificado";
    res.render('tabela', { produtos, usuario: req.session.usuario, ultimoAcesso });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
